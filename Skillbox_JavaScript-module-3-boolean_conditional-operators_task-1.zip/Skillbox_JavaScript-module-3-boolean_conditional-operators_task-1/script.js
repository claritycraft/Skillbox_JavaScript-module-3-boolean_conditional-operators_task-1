let cashCredit = prompt('Введите сумму: ')

let cardInside = true;

if (cardInside && cashCredit <= 500) {
  console.log('Ввод :', cashCredit);
  console.log('Вывод : операция успешна');
} else {
  console.log('Ввод :', cashCredit);
  console.log('Вывод : операция отклонена');
    
}
